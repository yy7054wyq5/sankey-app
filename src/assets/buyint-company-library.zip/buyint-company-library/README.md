## 打包上传步骤
1. 执行编译命令 `tsc`
2. 修改系统配置config `npm config set registry http://beta.baiye.local:18081/repository/npm-hosted/`
3. 登录用户 `npm login` 用户名和密码联系管理员获得
4. 执行发布命令　`npm publish`
5. 改回原有的配置　`npm config set registry http://beta.baiye.local:18081/repository/npm-group/`  
   > 获取原有配置命令　`npm config get registry`